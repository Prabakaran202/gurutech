from django.contrib import admin
from .models import wishlist
# Register your models here.

admin.site.register(wishlist)